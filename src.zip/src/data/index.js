import * as data from './data.min'

export default data
