<template>
  <div>
    <h3>Dashboard</h3>
  </div>
</template>

<script>

</script>

<style lang="stylus" scoped>

</style>
